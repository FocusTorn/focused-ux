export const ghostWriterConstants = {
	storageKeys: {
		CLIPBOARD: 'fux-ghost-writer.clipboard',
	},
} as const
