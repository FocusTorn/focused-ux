export interface ICoreQuickPickItem {
	label: string
	description?: string
	iconNameInDefinitions: string
	iconPath: string
}
