import type { ExtensionContext, Disposable, Uri } from 'vscode'
import type { IProjectButlerService } from '@fux/project-butler-core'
import { createDIContainer } from './injection.js'
import { constants } from './_config/constants.js'

export async function activate(context: ExtensionContext): Promise<void> {
	console.log(`[${constants.extension.name}] Activating...`)

	let container: any = null

	try {
		container = await createDIContainer(context)

		const extensionContext = container.resolve('extensionContext')
		const extensionAPI = container.resolve('extensionAPI')
		const projectButlerService = container.resolve('projectButlerService') as IProjectButlerService

		const disposables: Disposable[] = [
			extensionAPI.registerCommand(constants.commands.updateTerminalPath, (uri?: Uri) =>
				projectButlerService.updateTerminalPath(uri?.fsPath)),

			extensionAPI.registerCommand(constants.commands.createBackup, (uri?: Uri) =>
				projectButlerService.createBackup(uri?.fsPath)),

			extensionAPI.registerCommand(constants.commands.enterPoetryShell, (uri?: Uri) =>
				projectButlerService.enterPoetryShell(uri?.fsPath)),

			extensionAPI.registerCommand(constants.commands.formatPackageJson, (uri?: Uri) =>
				projectButlerService.formatPackageJson(uri?.fsPath)),
		]

		extensionContext.subscriptions.push(...disposables)
		console.log(`[${constants.extension.name}] Activated successfully.`)
	}
	catch (error) {
		console.error(`[${constants.extension.name}] Failed to activate:`, error)

		// Try to show error message using container if available, otherwise fall back to console
		if (container) {
			try {
				const windowAdapter = container.resolve('window')

				windowAdapter.showErrorMessage(`Failed to activate ${constants.extension.name}: ${error instanceof Error ? error.message : 'Unknown error'}`)
			}
			catch (containerError) {
				console.error(`[${constants.extension.name}] Failed to show error message:`, containerError)
			}
		}
		else {
			console.error(`[${constants.extension.name}] Container creation failed, cannot show error message to user`)
		}
	}
}

export function deactivate(): void {}
