import { describe, it, expect, beforeEach, vi } from 'vitest'
import { createDIContainer } from '../../src/injection.js'
import { mockly, mocklyService } from '@fux/mockly'
import type { ExtensionContext } from 'vscode'

describe('Project Butler Extension - Real Injection Integration', () => {
	let mockContext: ExtensionContext

	beforeEach(() => {
		mocklyService.reset()
		
		mockContext = {
			subscriptions: [],
			workspaceState: mockly.Memento,
			globalState: mockly.Memento,
			extensionPath: '/test/extension/path',
			extensionUri: mockly.Uri.file('/test/extension/path'),
			environmentVariableCollection: {
				replace: vi.fn(),
				append: vi.fn(),
				prepend: vi.fn(),
				delete: vi.fn(),
			},
		} as ExtensionContext
	})

	describe('Real DI Container Creation', () => {
		it('should create container with real shared adapters', async () => {
			// Test that the REAL DI container can be created
			const container = await createDIContainer(mockContext)
			
			expect(container).toBeDefined()
			expect(container.cradle).toBeDefined()
		})

		it('should resolve all required services from real container', async () => {
			const container = await createDIContainer(mockContext)
			
			// Test that all services can be resolved
			expect(container.resolve('fileSystem')).toBeDefined()
			expect(container.resolve('workspace')).toBeDefined()
			expect(container.resolve('process')).toBeDefined()
			expect(container.resolve('terminalProvider')).toBeDefined()
			expect(container.resolve('path')).toBeDefined()
			expect(container.resolve('extensionContext')).toBeDefined()
			expect(container.resolve('extensionAPI')).toBeDefined()
			expect(container.resolve('configurationService')).toBeDefined()
			expect(container.resolve('window')).toBeDefined()
			expect(container.resolve('projectButlerService')).toBeDefined()
		})

		it('should inject shared adapters into core services', async () => {
			const container = await createDIContainer(mockContext)
			
			// Test that ProjectButlerService can be resolved and has correct interface
			const projectButlerService = container.resolve('projectButlerService')
			
			expect(projectButlerService).toBeDefined()
			expect(typeof projectButlerService.updateTerminalPath).toBe('function')
			expect(typeof projectButlerService.createBackup).toBe('function')
			expect(typeof projectButlerService.enterPoetryShell).toBe('function')
			expect(typeof projectButlerService.formatPackageJson).toBe('function')
		})

		it('should create core container with injected shared adapters', async () => {
			const container = await createDIContainer(mockContext)
			
			// Get the shared adapters that should be injected into core
			const fileSystem = container.resolve('fileSystem')
			const window = container.resolve('window')
			const terminalProvider = container.resolve('terminalProvider')
			const process = container.resolve('process')
			const path = container.resolve('path')
			
			// Verify they implement the expected interfaces
			expect(typeof fileSystem.access).toBe('function')
			expect(typeof fileSystem.copyFile).toBe('function')
			expect(typeof fileSystem.stat).toBe('function')
			expect(typeof fileSystem.readFile).toBe('function')
			expect(typeof fileSystem.writeFile).toBe('function')
			
			expect(typeof window.showErrorMessage).toBe('function')
			expect(typeof window.showTimedInformationMessage).toBe('function')
			
			expect(typeof terminalProvider.createTerminal).toBe('function')
			
			expect(typeof process.getWorkspaceRoot).toBe('function')
			
			expect(typeof path.basename).toBe('function')
			expect(typeof path.join).toBe('function')
			expect(typeof path.dirname).toBe('function')
			expect(typeof path.relative).toBe('function')
		})
	})

	describe('Runtime Injection Validation', () => {
		it('should handle service method calls without errors', async () => {
			const container = await createDIContainer(mockContext)
			const projectButlerService = container.resolve('projectButlerService')
			
			// Test that injected services work without throwing errors
			// This validates that the injection was successful
			await expect(projectButlerService.updateTerminalPath('/test/path')).resolves.not.toThrow()
			await expect(projectButlerService.createBackup('/test/file.txt')).resolves.not.toThrow()
			await expect(projectButlerService.enterPoetryShell('/test/path')).resolves.not.toThrow()
			await expect(projectButlerService.formatPackageJson('/test/package.json')).resolves.not.toThrow()
		})

		it('should use injected shared adapters instead of direct imports', async () => {
			const container = await createDIContainer(mockContext)
			
			// Verify that services are using injected adapters by checking
			// that they don't fail due to missing shared adapter imports
			const fileSystem = container.resolve('fileSystem')
			const configurationService = container.resolve('configurationService')
			
			// These should work because they use injected adapters
			expect(() => fileSystem.access('/test/path')).not.toThrow()
			expect(() => configurationService.get('test.key')).not.toThrow()
		})

		it('should wire dependencies correctly', async () => {
			const container = await createDIContainer(mockContext)
			
			// Test that dependent services are correctly wired
			const configurationService = container.resolve('configurationService')
			const window = container.resolve('window')
			const process = container.resolve('process')
			
			// ConfigurationService should have fileSystem and process injected
			expect(configurationService).toBeDefined()
			
			// WindowAdapter should have configurationService injected
			expect(window).toBeDefined()
			
			// ProcessAdapter should have workspace injected
			expect(process).toBeDefined()
		})
	})

	describe('Extension Context Integration', () => {
		it('should register extension context adapter', async () => {
			const container = await createDIContainer(mockContext)
			
			const extensionContext = container.resolve('extensionContext')
			expect(extensionContext).toBeDefined()
			expect(extensionContext.subscriptions).toBeDefined()
		})

		it('should register extension API adapter', async () => {
			const container = await createDIContainer(mockContext)
			
			const extensionAPI = container.resolve('extensionAPI')
			expect(extensionAPI).toBeDefined()
			expect(typeof extensionAPI.registerCommand).toBe('function')
		})
	})

	describe('Singleton Behavior', () => {
		it('should resolve same instances for singleton services', async () => {
			const container = await createDIContainer(mockContext)
			
			// Test that singleton services return the same instance
			const fileSystem1 = container.resolve('fileSystem')
			const fileSystem2 = container.resolve('fileSystem')
			expect(fileSystem1).toBe(fileSystem2)
			
			const projectButlerService1 = container.resolve('projectButlerService')
			const projectButlerService2 = container.resolve('projectButlerService')
			expect(projectButlerService1).toBe(projectButlerService2)
		})
	})

	describe('Error Resilience', () => {
		it('should handle container creation without throwing', async () => {
			// Test that container creation is robust
			await expect(createDIContainer(mockContext)).resolves.toBeDefined()
		})

		it('should handle service resolution without throwing', async () => {
			const container = await createDIContainer(mockContext)
			
			// Test that all service resolutions work
			expect(() => container.resolve('fileSystem')).not.toThrow()
			expect(() => container.resolve('projectButlerService')).not.toThrow()
			expect(() => container.resolve('configurationService')).not.toThrow()
		})
	})
})