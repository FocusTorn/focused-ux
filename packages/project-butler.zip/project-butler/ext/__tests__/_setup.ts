import { vi, beforeAll, afterAll, afterEach, beforeEach } from 'vitest'
import { mockly, mocklyService } from '@fux/mockly'

// Create wrapper functions that are Vitest mocks for testing
const mockShowErrorMessage = vi.fn().mockImplementation((message: string) => {
	// Mock implementation - suppress output
})

const mockShowTimedInformationMessage = vi.fn().mockImplementation((message: string) => {
	// Mock implementation - suppress output
})

// Create wrapper functions for file system methods
const mockFsAccess = vi.fn().mockResolvedValue(undefined)
const mockFsCopyFile = vi.fn().mockResolvedValue(undefined)
const mockFsStat = vi.fn().mockResolvedValue({
	type: 1, // File
	size: 1024,
	ctime: Date.now(),
	mtime: Date.now(),
})
const mockFsReadFile = vi.fn().mockResolvedValue('file content')
const mockFsWriteFile = vi.fn().mockResolvedValue(undefined)

// Create wrapper functions for terminal methods
const mockTerminalSendText = vi.fn().mockImplementation((text: string) => {
	// Mock implementation - suppress output
})

const mockTerminalShow = vi.fn().mockImplementation(() => {
	// Mock implementation - suppress output
})

// Create wrapper functions for path methods
const mockPathBasename = vi.fn().mockReturnValue('file.txt')
const mockPathJoin = vi.fn().mockReturnValue('/test/file.txt')
const mockPathDirname = vi.fn().mockReturnValue('/test')
const mockPathRelative = vi.fn().mockReturnValue('file.txt')

// Create wrapper functions for process and workspace methods
const mockGetWorkspaceRoot = vi.fn().mockReturnValue('/test/workspace')

// Create wrapper functions for configuration service methods
const mockConfigGet = vi.fn().mockReturnValue('test-value')
const mockConfigUpdate = vi.fn().mockResolvedValue(undefined)

// Create wrapper functions for project butler service methods
const mockUpdateTerminalPath = vi.fn().mockResolvedValue(undefined)
const mockCreateBackup = vi.fn().mockResolvedValue(undefined)
const mockEnterPoetryShell = vi.fn().mockResolvedValue(undefined)
const mockFormatPackageJson = vi.fn().mockResolvedValue(undefined)

// Create wrapper functions for extension context and API
const mockExtensionContextSubscriptions = []
const mockExtensionContextPush = vi.fn()
const mockExtensionAPIRegisterCommand = vi.fn().mockReturnValue({
	dispose: vi.fn(),
})

// 2) Use fake timers globally (no real 1.5s waits)
beforeAll(() => {
	vi.useFakeTimers()
})

afterAll(() => {
	vi.useRealTimers()
})

// 3) Keep mocks clean between tests
afterEach(() => {
	vi.clearAllMocks()
})

// Reset Mockly state between tests
beforeEach(() => {
	mocklyService.reset()
	
	// Clear all mock calls to prevent persistence between tests
	mockShowErrorMessage.mockClear()
	mockShowTimedInformationMessage.mockClear()
	mockFsAccess.mockClear()
	mockFsCopyFile.mockClear()
	mockFsStat.mockClear()
	mockFsReadFile.mockClear()
	mockFsWriteFile.mockClear()
	mockTerminalSendText.mockClear()
	mockTerminalShow.mockClear()
	mockPathBasename.mockClear()
	mockPathJoin.mockClear()
	mockPathDirname.mockClear()
	mockPathRelative.mockClear()
	mockGetWorkspaceRoot.mockClear()
	mockConfigGet.mockClear()
	mockConfigUpdate.mockClear()
	mockUpdateTerminalPath.mockClear()
	mockCreateBackup.mockClear()
	mockEnterPoetryShell.mockClear()
	mockFormatPackageJson.mockClear()
	mockExtensionContextPush.mockClear()
	mockExtensionAPIRegisterCommand.mockClear()
	
	// Reset arrays
	mockExtensionContextSubscriptions.length = 0
})

// Mock the injection module to use our mocks
vi.mock('../src/injection.js', async () => {
	const actual = await vi.importActual('../src/injection.js')

	return {
		...actual,
		createDIContainer: vi.fn().mockImplementation(async () => {
			const { createContainer, InjectionMode, asValue, asClass } = await import('awilix')
			
			const container = createContainer({
				injectionMode: InjectionMode.PROXY,
			})
			
			// Register mock adapters
			container.register({
				fileSystem: asValue({
					stat: mockFsStat,
					access: mockFsAccess,
					copyFile: mockFsCopyFile,
					readFile: mockFsReadFile,
					writeFile: mockFsWriteFile,
				}),
				workspace: asValue({
					getWorkspaceRoot: mockGetWorkspaceRoot,
				}),
				process: asValue({
					getWorkspaceRoot: mockGetWorkspaceRoot,
				}),
				terminalProvider: asValue({
					activeTerminal: undefined,
					createTerminal: vi.fn().mockReturnValue({
						name: 'Test Terminal',
						sendText: mockTerminalSendText,
						show: mockTerminalShow,
						hide: vi.fn(),
						dispose: vi.fn(),
						processId: Promise.resolve(1),
						creationOptions: {},
						exitStatus: undefined,
						state: 1,
						shellIntegration: undefined,
					}),
				}),
				path: asValue({
					basename: mockPathBasename,
					join: mockPathJoin,
					dirname: mockPathDirname,
					relative: mockPathRelative,
				}),
				extensionContext: asValue({
					subscriptions: mockExtensionContextSubscriptions,
					push: mockExtensionContextPush,
				}),
				extensionAPI: asValue({
					registerCommand: mockExtensionAPIRegisterCommand,
				}),
			})
			
			// Register mock services
			container.register({
				configurationService: asValue({
					get: mockConfigGet,
					update: mockConfigUpdate,
				}),
				window: asValue({
					activeTextEditorUri: undefined,
					showErrorMessage: mockShowErrorMessage,
					showTimedInformationMessage: mockShowTimedInformationMessage,
				}),
				projectButlerService: asValue({
					updateTerminalPath: mockUpdateTerminalPath,
					createBackup: mockCreateBackup,
					enterPoetryShell: mockEnterPoetryShell,
					formatPackageJson: mockFormatPackageJson,
				}),
			})
			
			return container
		}),
	}
})

// Mock shared adapters to return our mocks
vi.mock('@fux/shared', () => ({
	ConfigurationService: vi.fn().mockImplementation(() => ({
		get: mockConfigGet,
		update: mockConfigUpdate,
	})),
	FileSystemAdapter: vi.fn().mockImplementation(() => ({
		stat: mockFsStat,
		access: mockFsAccess,
		copyFile: mockFsCopyFile,
		readFile: mockFsReadFile,
		writeFile: mockFsWriteFile,
	})),
	TerminalAdapter: vi.fn().mockImplementation(() => ({
		activeTerminal: undefined,
		createTerminal: vi.fn().mockReturnValue({
			name: 'Test Terminal',
			sendText: mockTerminalSendText,
			show: mockTerminalShow,
			hide: vi.fn(),
			dispose: vi.fn(),
			processId: Promise.resolve(1),
			creationOptions: {},
			exitStatus: undefined,
			state: 1,
			shellIntegration: undefined,
		}),
	})),
	WindowAdapter: vi.fn().mockImplementation(() => ({
		activeTextEditorUri: undefined,
		showErrorMessage: mockShowErrorMessage,
		showTimedInformationMessage: mockShowTimedInformationMessage,
	})),
	ProcessAdapter: vi.fn().mockImplementation(() => ({
		getWorkspaceRoot: mockGetWorkspaceRoot,
	})),
	WorkspaceAdapter: vi.fn().mockImplementation(() => ({
		getWorkspaceRoot: mockGetWorkspaceRoot,
	})),
	PathAdapter: vi.fn().mockImplementation(() => ({
		basename: mockPathBasename,
		join: mockPathJoin,
		dirname: mockPathDirname,
		relative: mockPathRelative,
	})),
	ExtensionContextAdapter: vi.fn().mockImplementation(() => ({
		subscriptions: mockExtensionContextSubscriptions,
		push: mockExtensionContextPush,
	})),
	ExtensionAPIAdapter: vi.fn().mockImplementation(() => ({
		registerCommand: mockExtensionAPIRegisterCommand,
	})),
}))

// Helper functions to create mock objects for tests
export function createMockFileSystemAdapter() {
	return {
		stat: mockFsStat,
		access: mockFsAccess,
		copyFile: mockFsCopyFile,
		readFile: mockFsReadFile,
		writeFile: mockFsWriteFile,
	}
}

export function createMockWindowAdapter() {
	return {
		activeTextEditorUri: mockly.window.activeTextEditorUri,
		showErrorMessage: mockShowErrorMessage,
		showTimedInformationMessage: mockShowTimedInformationMessage,
	}
}

export function createMockTerminalAdapter() {
	return {
		activeTerminal: undefined,
		createTerminal: vi.fn().mockReturnValue({
			name: 'Test Terminal',
			sendText: mockTerminalSendText,
			show: mockTerminalShow,
			hide: vi.fn(),
			dispose: vi.fn(),
			processId: Promise.resolve(1),
			creationOptions: {},
			exitStatus: undefined,
			state: 1,
			shellIntegration: undefined,
		}),
	}
}

// Export mock functions for use in tests
export {
	mockShowErrorMessage,
	mockShowTimedInformationMessage,
	mockFsAccess,
	mockFsCopyFile,
	mockFsStat,
	mockFsReadFile,
	mockFsWriteFile,
	mockTerminalSendText,
	mockTerminalShow,
	mockPathBasename,
	mockPathJoin,
	mockPathDirname,
	mockPathRelative,
	mockGetWorkspaceRoot,
	mockConfigGet,
	mockConfigUpdate,
	mockUpdateTerminalPath,
	mockCreateBackup,
	mockEnterPoetryShell,
	mockFormatPackageJson,
	mockExtensionContextPush,
	mockExtensionAPIRegisterCommand,
	mockExtensionContextSubscriptions,
	mockly,
	mocklyService,
}

// Mock VSCode extension context using Mockly
vi.mock('vscode', () => ({
	ExtensionContext: vi.fn().mockImplementation(() => ({
		subscriptions: [],
		workspaceState: mockly.Memento,
		globalState: mockly.Memento,
		extensionPath: '/test/extension/path',
		extensionUri: mockly.Uri.file('/test/extension/path'),
		environmentVariableCollection: {
			replace: vi.fn(),
			append: vi.fn(),
			prepend: vi.fn(),
			delete: vi.fn(),
		},
	})),
	Uri: mockly.Uri,
	Disposable: mockly.Disposable,
	// Add other VSCode APIs as needed
}))
