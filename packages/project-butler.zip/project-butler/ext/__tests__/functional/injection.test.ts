import { describe, it, expect, vi, beforeEach } from 'vitest'
import { createDIContainer } from '../../src/injection.js'
import type { ExtensionContext } from 'vscode'

describe('Extension DI Container', () => {
	let mockContext: ExtensionContext

	beforeEach(() => {
		// Reset all mocks
		vi.clearAllMocks()

		// Create a fresh mock context for each test
		mockContext = {
			subscriptions: [],
			workspaceState: {
				get: vi.fn(),
				update: vi.fn(),
			},
			globalState: {
				get: vi.fn(),
				update: vi.fn(),
			},
			extensionPath: '/test/extension/path',
			extensionUri: { fsPath: '/test/extension/path' },
			environmentVariableCollection: {
				replace: vi.fn(),
				append: vi.fn(),
				prepend: vi.fn(),
				delete: vi.fn(),
			},
		} as any
	})

	describe('createDIContainer', () => {
		it('should create a DI container successfully', async () => {
			const container = await createDIContainer(mockContext)

			expect(container).toBeDefined()
			expect(typeof container.resolve).toBe('function')
		})

		it('should register all required services', async () => {
			const container = await createDIContainer(mockContext)

			// Test that we can resolve all the key services
			expect(() => container.resolve('fileSystem')).not.toThrow()
			expect(() => container.resolve('workspace')).not.toThrow()
			expect(() => container.resolve('process')).not.toThrow()
			expect(() => container.resolve('terminalProvider')).not.toThrow()
			expect(() => container.resolve('path')).not.toThrow()
			expect(() => container.resolve('extensionContext')).not.toThrow()
			expect(() => container.resolve('extensionAPI')).not.toThrow()
			expect(() => container.resolve('projectButlerService')).not.toThrow()
			expect(() => container.resolve('configurationService')).not.toThrow()
			expect(() => container.resolve('window')).not.toThrow()
		})

		it('should register projectButlerService from core container', async () => {
			const container = await createDIContainer(mockContext)

			const projectButlerService = container.resolve('projectButlerService')

			expect(projectButlerService).toBeDefined()
			expect(projectButlerService.updateTerminalPath).toBeDefined()
			expect(projectButlerService.createBackup).toBeDefined()
			expect(projectButlerService.enterPoetryShell).toBeDefined()
			expect(projectButlerService.formatPackageJson).toBeDefined()
		})

		it('should register configurationService with correct dependencies', async () => {
			const container = await createDIContainer(mockContext)

			const configurationService = container.resolve('configurationService')

			expect(configurationService).toBeDefined()
			expect(configurationService.get).toBeDefined()
			expect(configurationService.update).toBeDefined()
		})

		it('should register window adapter with configuration service dependency', async () => {
			const container = await createDIContainer(mockContext)

			const window = container.resolve('window')

			expect(window).toBeDefined()
			expect(window.showErrorMessage).toBeDefined()
			expect(window.showTimedInformationMessage).toBeDefined()
		})

		it('should register process adapter with workspace dependency', async () => {
			const container = await createDIContainer(mockContext)

			const process = container.resolve('process')

			expect(process).toBeDefined()
			expect(process.getWorkspaceRoot).toBeDefined()
		})

		it('should register extension context adapter', async () => {
			const container = await createDIContainer(mockContext)

			const extensionContext = container.resolve('extensionContext')

			expect(extensionContext).toBeDefined()
			expect(extensionContext.subscriptions).toBeDefined()
		})

		it('should register extension API adapter', async () => {
			const container = await createDIContainer(mockContext)

			const extensionAPI = container.resolve('extensionAPI')

			expect(extensionAPI).toBeDefined()
			expect(typeof extensionAPI.registerCommand).toBe('function')
		})

		it('should register path adapter', async () => {
			const container = await createDIContainer(mockContext)

			const path = container.resolve('path')

			expect(path).toBeDefined()
			expect(typeof path.basename).toBe('function')
			expect(typeof path.join).toBe('function')
			expect(typeof path.dirname).toBe('function')
			expect(typeof path.relative).toBe('function')
		})
	})

	describe('Service Dependencies', () => {
		it('should inject fileSystem with correct interface', async () => {
			const container = await createDIContainer(mockContext)
			const fileSystem = container.resolve('fileSystem')

			expect(fileSystem.stat).toBeDefined()
			expect(fileSystem.access).toBeDefined()
			expect(fileSystem.copyFile).toBeDefined()
			expect(fileSystem.readFile).toBeDefined()
			expect(fileSystem.writeFile).toBeDefined()
		})

		it('should inject terminalProvider with correct interface', async () => {
			const container = await createDIContainer(mockContext)
			const terminalProvider = container.resolve('terminalProvider')

			expect('activeTerminal' in terminalProvider).toBe(true)
			expect('createTerminal' in terminalProvider).toBe(true)
			expect(typeof terminalProvider.createTerminal).toBe('function')
		})

		it('should inject window with correct interface', async () => {
			const container = await createDIContainer(mockContext)
			const window = container.resolve('window')

			expect(window.showErrorMessage).toBeDefined()
			expect(window.showTimedInformationMessage).toBeDefined()
		})

		it('should inject process with correct interface', async () => {
			const container = await createDIContainer(mockContext)
			const process = container.resolve('process')

			expect(process.getWorkspaceRoot).toBeDefined()
		})

		it('should inject workspace with correct interface', async () => {
			const container = await createDIContainer(mockContext)
			const workspace = container.resolve('workspace')

			expect(workspace.getWorkspaceRoot).toBeDefined()
		})

		it('should inject path with correct interface', async () => {
			const container = await createDIContainer(mockContext)
			const path = container.resolve('path')

			expect(typeof path.basename).toBe('function')
			expect(typeof path.join).toBe('function')
			expect(typeof path.dirname).toBe('function')
			expect(typeof path.relative).toBe('function')
		})
	})

	describe('Service Resolution', () => {
		it('should resolve fileSystem as singleton', async () => {
			const container = await createDIContainer(mockContext)
			const fileSystem1 = container.resolve('fileSystem')
			const fileSystem2 = container.resolve('fileSystem')

			expect(fileSystem1).toBe(fileSystem2)
		})

		it('should resolve workspace as singleton', async () => {
			const container = await createDIContainer(mockContext)
			const workspace1 = container.resolve('workspace')
			const workspace2 = container.resolve('workspace')

			expect(workspace1).toBe(workspace2)
		})

		it('should resolve process as singleton', async () => {
			const container = await createDIContainer(mockContext)
			const process1 = container.resolve('process')
			const process2 = container.resolve('process')

			expect(process1).toBe(process2)
		})

		it('should resolve terminalProvider as singleton', async () => {
			const container = await createDIContainer(mockContext)
			const terminalProvider1 = container.resolve('terminalProvider')
			const terminalProvider2 = container.resolve('terminalProvider')

			expect(terminalProvider1).toBe(terminalProvider2)
		})

		it('should resolve projectButlerService as singleton', async () => {
			const container = await createDIContainer(mockContext)
			const projectButlerService1 = container.resolve('projectButlerService')
			const projectButlerService2 = container.resolve('projectButlerService')

			expect(projectButlerService1).toBe(projectButlerService2)
		})

		it('should resolve configurationService as singleton', async () => {
			const container = await createDIContainer(mockContext)
			const configurationService1 = container.resolve('configurationService')
			const configurationService2 = container.resolve('configurationService')

			expect(configurationService1).toBe(configurationService2)
		})

		it('should resolve window as singleton', async () => {
			const container = await createDIContainer(mockContext)
			const window1 = container.resolve('window')
			const window2 = container.resolve('window')

			expect(window1).toBe(window2)
		})

		it('should resolve path as singleton', async () => {
			const container = await createDIContainer(mockContext)
			const path1 = container.resolve('path')
			const path2 = container.resolve('path')

			expect(path1).toBe(path2)
		})

		it('should resolve extensionContext as singleton', async () => {
			const container = await createDIContainer(mockContext)
			const extensionContext1 = container.resolve('extensionContext')
			const extensionContext2 = container.resolve('extensionContext')

			expect(extensionContext1).toBe(extensionContext2)
		})

		it('should resolve extensionAPI as singleton', async () => {
			const container = await createDIContainer(mockContext)
			const extensionAPI1 = container.resolve('extensionAPI')
			const extensionAPI2 = container.resolve('extensionAPI')

			expect(extensionAPI1).toBe(extensionAPI2)
		})
	})

	describe('Service Functionality', () => {
		it('should provide working fileSystem methods', async () => {
			const container = await createDIContainer(mockContext)
			const fileSystem = container.resolve('fileSystem')

			await fileSystem.stat('/test/path')
			expect(fileSystem.stat).toHaveBeenCalledWith('/test/path')

			await fileSystem.access('/test/path')
			expect(fileSystem.access).toHaveBeenCalledWith('/test/path')

			await fileSystem.copyFile('/src', '/dest')
			expect(fileSystem.copyFile).toHaveBeenCalledWith('/src', '/dest')

			await fileSystem.readFile('/test/file.txt')
			expect(fileSystem.readFile).toHaveBeenCalledWith('/test/file.txt')

			await fileSystem.writeFile('/test/file.txt', new Uint8Array([1, 2, 3]))
			expect(fileSystem.writeFile).toHaveBeenCalledWith('/test/file.txt', new Uint8Array([1, 2, 3]))
		})

		it('should provide working terminalProvider methods', async () => {
			const container = await createDIContainer(mockContext)
			const terminalProvider = container.resolve('terminalProvider')

			const terminal = terminalProvider.createTerminal()

			expect(terminalProvider.createTerminal).toHaveBeenCalled()
			expect(terminal.name).toBe('Test Terminal')
		})

		it('should provide working window methods', async () => {
			const container = await createDIContainer(mockContext)
			const window = container.resolve('window')

			window.showErrorMessage('Test error')
			expect(window.showErrorMessage).toHaveBeenCalledWith('Test error')

			window.showTimedInformationMessage('Test info', 5000)
			expect(window.showTimedInformationMessage).toHaveBeenCalledWith('Test info', 5000)
		})

		it('should provide working process methods', async () => {
			const container = await createDIContainer(mockContext)
			const process = container.resolve('process')

			const workspaceRoot = process.getWorkspaceRoot()

			expect(process.getWorkspaceRoot).toHaveBeenCalled()
			expect(workspaceRoot).toBe('/test/workspace')
		})

		it('should provide working workspace methods', async () => {
			const container = await createDIContainer(mockContext)
			const workspace = container.resolve('workspace')

			const workspaceRoot = workspace.getWorkspaceRoot()

			expect(workspace.getWorkspaceRoot).toHaveBeenCalled()
			expect(workspaceRoot).toBe('/test/workspace')
		})

		it('should provide working path methods', async () => {
			const container = await createDIContainer(mockContext)
			const path = container.resolve('path')

			path.basename('/test/file.txt')
			expect(path.basename).toHaveBeenCalledWith('/test/file.txt')

			path.join('/test', 'file.txt')
			expect(path.join).toHaveBeenCalledWith('/test', 'file.txt')

			path.dirname('/test/file.txt')
			expect(path.dirname).toHaveBeenCalledWith('/test/file.txt')

			path.relative('/base', '/base/file.txt')
			expect(path.relative).toHaveBeenCalledWith('/base', '/base/file.txt')
		})

		it('should provide working projectButlerService methods', async () => {
			const container = await createDIContainer(mockContext)
			const projectButlerService = container.resolve('projectButlerService')

			await projectButlerService.updateTerminalPath('/test/path')
			expect(projectButlerService.updateTerminalPath).toHaveBeenCalledWith('/test/path')

			await projectButlerService.createBackup('/test/path')
			expect(projectButlerService.createBackup).toHaveBeenCalledWith('/test/path')

			await projectButlerService.enterPoetryShell('/test/path')
			expect(projectButlerService.enterPoetryShell).toHaveBeenCalledWith('/test/path')

			await projectButlerService.formatPackageJson('/test/path')
			expect(projectButlerService.formatPackageJson).toHaveBeenCalledWith('/test/path')
		})

		it('should provide working configurationService methods', async () => {
			const container = await createDIContainer(mockContext)
			const configurationService = container.resolve('configurationService')

			configurationService.get('test.key')
			expect(configurationService.get).toHaveBeenCalledWith('test.key')

			configurationService.update('test.key', 'test.value')
			expect(configurationService.update).toHaveBeenCalledWith('test.key', 'test.value')
		})
	})
})
