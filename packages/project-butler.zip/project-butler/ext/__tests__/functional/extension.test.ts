import { describe, it, expect, vi, beforeEach } from 'vitest'
import type { ExtensionContext, Uri } from 'vscode'
import {
	mockExtensionContextSubscriptions,
	mockExtensionAPIRegisterCommand,
	mockUpdateTerminalPath,
	mockCreateBackup,
	mockEnterPoetryShell,
	mockFormatPackageJson,
} from '../_setup.js'

describe('Extension Activation', () => {
	let mockContext: ExtensionContext

	beforeEach(async () => {
		// Reset all mocks
		vi.clearAllMocks()

		// Mock console.error for error testing
		vi.spyOn(console, 'error').mockImplementation(() => {})
		vi.spyOn(console, 'log').mockImplementation(() => {})

		// Create a fresh mock context for each test
		mockContext = {
			subscriptions: {
				push: vi.fn() as any,
			},
			workspaceState: {
				get: vi.fn(),
				update: vi.fn(),
			},
			globalState: {
				get: vi.fn(),
				update: vi.fn(),
			},
			extensionPath: '/test/extension/path',
			extensionUri: { fsPath: '/test/extension/path' },
			environmentVariableCollection: {
				replace: vi.fn(),
				append: vi.fn(),
				prepend: vi.fn(),
				delete: vi.fn(),
			},
		} as any

		// Reset mock instances to clean state
		mockExtensionContextSubscriptions.length = 0
		mockExtensionAPIRegisterCommand.mockClear()
		mockUpdateTerminalPath.mockClear()
		mockCreateBackup.mockClear()
		mockEnterPoetryShell.mockClear()
		mockFormatPackageJson.mockClear()
	})

	describe('activate function', () => {
		it('should activate successfully with all commands registered', async () => {
			const { activate } = await import('../../src/extension.js')

			await activate(mockContext)

			// Verify DI container was created
			const { createDIContainer } = await import('../../src/injection.js')

			expect(createDIContainer).toHaveBeenCalledWith(mockContext)

			// Verify all commands were registered (4 commands, not 5)
			expect(mockExtensionAPIRegisterCommand).toHaveBeenCalledTimes(4)
			expect(mockExtensionAPIRegisterCommand).toHaveBeenCalledWith(
				'fux-project-butler-dc.updateTerminalPath',
				expect.any(Function),
			)
			expect(mockExtensionAPIRegisterCommand).toHaveBeenCalledWith(
				'fux-project-butler-dc.createBackup',
				expect.any(Function),
			)
			expect(mockExtensionAPIRegisterCommand).toHaveBeenCalledWith(
				'fux-project-butler-dc.enterPoetryShell',
				expect.any(Function),
			)
			expect(mockExtensionAPIRegisterCommand).toHaveBeenCalledWith(
				'fux-project-butler-dc.formatPackageJson',
				expect.any(Function),
			)
		})

		it('should add disposables to context subscriptions', async () => {
			const { activate } = await import('../../src/extension.js')

			await activate(mockContext)

			// Verify disposables were added to subscriptions (4 commands, not 5)
			expect(mockExtensionContextSubscriptions).toHaveLength(4)
			expect(mockExtensionContextSubscriptions).toEqual(
				expect.arrayContaining([
					expect.objectContaining({
						dispose: expect.any(Function),
					}),
				]),
			)
		})

		it('should log activation success', async () => {
			const { activate } = await import('../../src/extension.js')

			await activate(mockContext)

			expect(console.log).toHaveBeenCalledWith('[F-UX: Project Butler] Activating...')
			expect(console.log).toHaveBeenCalledWith('[F-UX: Project Butler] Activated successfully.')
		})
	})

	describe('Command Handlers', () => {
		const commandHandlers: { [key: string]: (uri?: Uri) => Promise<void> } = {}

		beforeEach(async () => {
			const { activate } = await import('../../src/extension.js')

			await activate(mockContext)

			// Extract command handlers from the registration calls
			const registerCommandCalls = vi.mocked(mockExtensionAPIRegisterCommand).mock.calls

			registerCommandCalls.forEach(([commandId, handler]) => {
				if (typeof commandId === 'string' && typeof handler === 'function') {
					commandHandlers[commandId] = handler as (uri?: Uri) => Promise<void>
				}
			})
		})

		describe('updateTerminalPath command', () => {
			it('should call projectButlerService.updateTerminalPath with URI fsPath', async () => {
				const handler = commandHandlers['fux-project-butler-dc.updateTerminalPath']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')
				
				const mockUri = { fsPath: '/test/path/file.txt' } as Uri

				await handler(mockUri)

				expect(mockUpdateTerminalPath).toHaveBeenCalledWith('/test/path/file.txt')
			})

			it('should call projectButlerService.updateTerminalPath with undefined when no URI', async () => {
				const handler = commandHandlers['fux-project-butler-dc.updateTerminalPath']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')

				await handler(undefined)

				expect(mockUpdateTerminalPath).toHaveBeenCalledWith(undefined)
			})

			it('should handle service errors gracefully', async () => {
				const handler = commandHandlers['fux-project-butler-dc.updateTerminalPath']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')
				
				const mockUri = { fsPath: '/test/path/file.txt' } as Uri
				const error = new Error('Service error')

				mockUpdateTerminalPath.mockRejectedValueOnce(error)

				await expect(handler(mockUri)).rejects.toThrow('Service error')
			})
		})

		describe('createBackup command', () => {
			it('should call projectButlerService.createBackup with URI fsPath', async () => {
				const handler = commandHandlers['fux-project-butler-dc.createBackup']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')
				
				const mockUri = { fsPath: '/test/path/file.txt' } as Uri

				await handler(mockUri)

				expect(mockCreateBackup).toHaveBeenCalledWith('/test/path/file.txt')
			})

			it('should call projectButlerService.createBackup with undefined when no URI', async () => {
				const handler = commandHandlers['fux-project-butler-dc.createBackup']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')

				await handler(undefined)

				expect(mockCreateBackup).toHaveBeenCalledWith(undefined)
			})

			it('should handle service errors gracefully', async () => {
				const handler = commandHandlers['fux-project-butler-dc.createBackup']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')
				
				const mockUri = { fsPath: '/test/path/file.txt' } as Uri
				const error = new Error('Service error')

				mockCreateBackup.mockRejectedValueOnce(error)

				await expect(handler(mockUri)).rejects.toThrow('Service error')
			})
		})

		describe('enterPoetryShell command', () => {
			it('should call projectButlerService.enterPoetryShell with URI fsPath', async () => {
				const handler = commandHandlers['fux-project-butler-dc.enterPoetryShell']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')
				
				const mockUri = { fsPath: '/test/path/file.txt' } as Uri

				await handler(mockUri)

				expect(mockEnterPoetryShell).toHaveBeenCalledWith('/test/path/file.txt')
			})

			it('should call projectButlerService.enterPoetryShell with undefined when no URI', async () => {
				const handler = commandHandlers['fux-project-butler-dc.enterPoetryShell']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')

				await handler(undefined)

				expect(mockEnterPoetryShell).toHaveBeenCalledWith(undefined)
			})

			it('should handle service errors gracefully', async () => {
				const handler = commandHandlers['fux-project-butler-dc.enterPoetryShell']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')
				
				const mockUri = { fsPath: '/test/path/file.txt' } as Uri
				const error = new Error('Service error')

				mockEnterPoetryShell.mockRejectedValueOnce(error)

				await expect(handler(mockUri)).rejects.toThrow('Service error')
			})
		})

		describe('formatPackageJson command', () => {
			it('should call projectButlerService.formatPackageJson with URI fsPath', async () => {
				const handler = commandHandlers['fux-project-butler-dc.formatPackageJson']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')
				
				const mockUri = { fsPath: '/test/path/package.json' } as Uri

				await handler(mockUri)

				expect(mockFormatPackageJson).toHaveBeenCalledWith('/test/path/package.json')
			})

			it('should call projectButlerService.formatPackageJson with undefined when no URI', async () => {
				const handler = commandHandlers['fux-project-butler-dc.formatPackageJson']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')

				await handler(undefined)

				expect(mockFormatPackageJson).toHaveBeenCalledWith(undefined)
			})

			it('should handle service errors gracefully', async () => {
				const handler = commandHandlers['fux-project-butler-dc.formatPackageJson']
				expect(handler).toBeDefined()
				expect(typeof handler).toBe('function')
				
				const mockUri = { fsPath: '/test/path/package.json' } as Uri
				const error = new Error('Service error')

				mockFormatPackageJson.mockRejectedValueOnce(error)

				await expect(handler(mockUri)).rejects.toThrow('Service error')
			})
		})
	})

	describe('Error Handling', () => {
		it('should handle container creation errors gracefully', async () => {
			const { createDIContainer } = await import('../../src/injection.js')

			vi.mocked(createDIContainer).mockRejectedValueOnce(new Error('Container creation failed'))

			const { activate } = await import('../../src/extension.js')

			// Should not throw
			await expect(activate(mockContext)).resolves.toBeUndefined()

			// Should log error
			expect(console.error).toHaveBeenCalledWith(
				'[F-UX: Project Butler] Failed to activate:',
				expect.any(Error),
			)
		})

		it('should show error message when container creation fails', async () => {
			const { createDIContainer } = await import('../../src/injection.js')

			vi.mocked(createDIContainer).mockRejectedValueOnce(new Error('Container creation failed'))

			const { activate } = await import('../../src/extension.js')

			await activate(mockContext)

			expect(console.error).toHaveBeenCalledWith(
				'[F-UX: Project Butler] Container creation failed, cannot show error message to user',
			)
		})
	})

	describe('deactivate function', () => {
		it('should exist and be callable', async () => {
			const { deactivate } = await import('../../src/extension.js')

			expect(deactivate).toBeDefined()
			expect(typeof deactivate).toBe('function')

			// Should not throw when called
			expect(() => deactivate()).not.toThrow()
		})
	})
})
