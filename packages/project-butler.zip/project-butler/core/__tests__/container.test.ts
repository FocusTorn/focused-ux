import { describe, it, expect, beforeEach, vi } from 'vitest'
import { createCoreContainer } from '../src/container.js'
import { mockly, mocklyService } from '@fux/mockly'
import type { IProjectButlerService } from '../src/_interfaces/IProjectButlerService.js'

describe('Project Butler Core DI Container', () => {
	beforeEach(() => {
		mocklyService.reset()
	})

	describe('Container Creation', () => {
		it('should create container with shared adapters', () => {
			// Test that container can be created with real shared adapters
			const container = createCoreContainer({
				fileSystem: mockly.fileSystem,
				window: mockly.window,
				terminalProvider: mockly.terminal,
				process: mockly.workspace,
				path: mockly.node.path,
			})

			expect(container).toBeDefined()
			expect(container.cradle).toBeDefined()
		})

		it('should resolve ProjectButlerService from container', () => {
			const container = createCoreContainer({
				fileSystem: mockly.fileSystem,
				window: mockly.window,
				terminalProvider: mockly.terminal,
				process: mockly.workspace,
				path: mockly.node.path,
			})

			const service = container.resolve('projectButlerService')
			expect(service).toBeDefined()
			expect(typeof service.updateTerminalPath).toBe('function')
			expect(typeof service.createBackup).toBe('function')
			expect(typeof service.enterPoetryShell).toBe('function')
			expect(typeof service.formatPackageJson).toBe('function')
		})

		it('should inject shared adapters into ProjectButlerService', () => {
			const container = createCoreContainer({
				fileSystem: mockly.fileSystem,
				window: mockly.window,
				terminalProvider: mockly.terminal,
				process: mockly.workspace,
				path: mockly.node.path,
			})

			const service = container.resolve('projectButlerService') as IProjectButlerService
			
			// Verify that the service has access to injected dependencies
			// This tests that the DI container properly wired the dependencies
			expect(service).toBeDefined()
			
			// The service should be able to use the injected adapters
			// We can't directly access private fields, but we can verify the service works
			expect(typeof service.updateTerminalPath).toBe('function')
		})
	})

	describe('Shared Adapter Injection', () => {
		it('should use injected fileSystem adapter', async () => {
			const mockFileSystem = {
				access: vi.fn().mockResolvedValue(undefined),
				copyFile: vi.fn().mockResolvedValue(undefined),
				stat: vi.fn().mockResolvedValue({ type: 1, size: 1024, ctime: Date.now(), mtime: Date.now() }),
				readFile: vi.fn().mockResolvedValue('test content'),
				writeFile: vi.fn().mockResolvedValue(undefined),
			}
			const mockWindow = {
				activeTextEditorUri: '/test/file.txt',
				showErrorMessage: vi.fn(),
				showTimedInformationMessage: vi.fn(),
			}
			const mockTerminal = {
				sendText: vi.fn(),
				show: vi.fn(),
			}
			const mockTerminalProvider = {
				activeTerminal: undefined,
				createTerminal: vi.fn().mockReturnValue(mockTerminal),
			}

			const container = createCoreContainer({
				fileSystem: mockFileSystem,
				window: mockWindow,
				terminalProvider: mockTerminalProvider,
				process: mockly.workspace,
				path: mockly.node.path,
			})

			const service = container.resolve('projectButlerService') as IProjectButlerService
			
			// Test that the service uses the injected fileSystem
			await service.updateTerminalPath('/test/path')
			
			expect(mockFileSystem.stat).toHaveBeenCalledWith('/test/path')
		})

		it('should use injected window adapter', async () => {
			const mockFileSystem = {
				access: vi.fn().mockResolvedValue(undefined),
				copyFile: vi.fn().mockResolvedValue(undefined),
				stat: vi.fn().mockResolvedValue({ type: 1, size: 1024, ctime: Date.now(), mtime: Date.now() }),
				readFile: vi.fn().mockResolvedValue('test content'),
				writeFile: vi.fn().mockResolvedValue(undefined),
			}
			const mockWindow = {
				activeTextEditorUri: '/test/file.txt',
				showErrorMessage: vi.fn(),
				showTimedInformationMessage: vi.fn(),
			}
			const mockTerminal = {
				sendText: vi.fn(),
				show: vi.fn(),
			}
			const mockTerminalProvider = {
				activeTerminal: undefined,
				createTerminal: vi.fn().mockReturnValue(mockTerminal),
			}

			const container = createCoreContainer({
				fileSystem: mockFileSystem,
				window: mockWindow,
				terminalProvider: mockTerminalProvider,
				process: mockly.workspace,
				path: mockly.node.path,
			})

			const service = container.resolve('projectButlerService') as IProjectButlerService
			
			// Test that the service uses the injected window
			await service.updateTerminalPath()
			
			expect(mockWindow.showErrorMessage).not.toHaveBeenCalled() // Should succeed with valid URI
		})

		it('should use injected terminalProvider adapter', async () => {
			const mockFileSystem = {
				access: vi.fn().mockResolvedValue(undefined),
				copyFile: vi.fn().mockResolvedValue(undefined),
				stat: vi.fn().mockResolvedValue({ type: 1, size: 1024, ctime: Date.now(), mtime: Date.now() }),
				readFile: vi.fn().mockResolvedValue('test content'),
				writeFile: vi.fn().mockResolvedValue(undefined),
			}
			const mockTerminal = {
				sendText: vi.fn(),
				show: vi.fn(),
			}
			const mockTerminalProvider = {
				activeTerminal: undefined,
				createTerminal: vi.fn().mockReturnValue(mockTerminal),
			}

			const mockWindow = {
				activeTextEditorUri: '/test/file.txt',
				showErrorMessage: vi.fn(),
				showTimedInformationMessage: vi.fn(),
			}

			const container = createCoreContainer({
				fileSystem: mockFileSystem,
				window: mockWindow,
				terminalProvider: mockTerminalProvider,
				process: mockly.workspace,
				path: mockly.node.path,
			})

			const service = container.resolve('projectButlerService') as IProjectButlerService
			
			// Test that the service uses the injected terminalProvider
			await service.updateTerminalPath('/test/path')
			
			expect(mockTerminalProvider.createTerminal).toHaveBeenCalledWith('F-UX Terminal')
			expect(mockTerminal.sendText).toHaveBeenCalled()
			expect(mockTerminal.show).toHaveBeenCalled()
		})

		it('should use injected process adapter', async () => {
			const mockProcess = {
				getWorkspaceRoot: vi.fn().mockReturnValue('/workspace/root'),
			}
			const mockWindow = {
				activeTextEditorUri: '/test/file.txt',
				showErrorMessage: vi.fn(),
				showTimedInformationMessage: vi.fn(),
			}
			const mockFileSystem = {
				access: vi.fn().mockResolvedValue(undefined),
				copyFile: vi.fn().mockResolvedValue(undefined),
				stat: vi.fn().mockResolvedValue({ type: 1, size: 1024, ctime: Date.now(), mtime: Date.now() }),
				readFile: vi.fn().mockResolvedValue('test content'),
				writeFile: vi.fn().mockResolvedValue(undefined),
			}

			const container = createCoreContainer({
				fileSystem: mockFileSystem,
				window: mockWindow,
				terminalProvider: mockly.terminal,
				process: mockProcess,
				path: mockly.node.path,
			})

			const service = container.resolve('projectButlerService') as IProjectButlerService
			
			// Test that the service uses the injected process
			await service.formatPackageJson('/test/package.json')
			
			expect(mockProcess.getWorkspaceRoot).toHaveBeenCalled()
		})

		it('should use injected path adapter', async () => {
			const mockPath = {
				basename: vi.fn().mockReturnValue('file.txt'),
				join: vi.fn().mockImplementation((...args) => args.join('/')),
				dirname: vi.fn().mockReturnValue('/test'),
				relative: vi.fn().mockReturnValue('relative/path'),
			}
			const mockWindow = {
				activeTextEditorUri: '/test/file.txt',
				showErrorMessage: vi.fn(),
				showTimedInformationMessage: vi.fn(),
			}
			const mockFileSystem = {
				access: vi.fn().mockResolvedValue(undefined),
				copyFile: vi.fn().mockResolvedValue(undefined),
				stat: vi.fn().mockResolvedValue({ type: 1, size: 1024, ctime: Date.now(), mtime: Date.now() }),
				readFile: vi.fn().mockResolvedValue('test content'),
				writeFile: vi.fn().mockResolvedValue(undefined),
			}

			const container = createCoreContainer({
				fileSystem: mockFileSystem,
				window: mockWindow,
				terminalProvider: mockly.terminal,
				process: mockly.workspace,
				path: mockPath,
			})

			const service = container.resolve('projectButlerService') as IProjectButlerService
			
			// Test that the service uses the injected path
			await service.createBackup('/test/file.txt')
			
			expect(mockPath.basename).toHaveBeenCalledWith('/test/file.txt')
			expect(mockPath.dirname).toHaveBeenCalledWith('/test/file.txt')
			expect(mockPath.join).toHaveBeenCalled()
		})
	})

	describe('Mockly Integration', () => {
		it('should work with Mockly adapters', () => {
			// Test that the container works with Mockly's built-in adapters
			const container = createCoreContainer({
				fileSystem: mockly.fileSystem,
				window: mockly.window,
				terminalProvider: mockly.terminal,
				process: mockly.workspace,
				path: mockly.node.path,
			})

			const service = container.resolve('projectButlerService')
			expect(service).toBeDefined()
		})

		it('should allow Mockly to replace shared adapters', () => {
			// Test that Mockly adapters can be injected as shared adapter replacements
			const container = createCoreContainer({
				fileSystem: mockly.fileSystem, // Mockly fileSystem instead of real shared
				window: mockly.window, // Mockly window instead of real shared
				terminalProvider: mockly.terminal, // Mockly terminal instead of real shared
				process: mockly.workspace, // Mockly workspace instead of real shared
				path: mockly.node.path, // Mockly path instead of real shared
			})

			const service = container.resolve('projectButlerService')
			expect(service).toBeDefined()
			
			// This verifies that the DI container accepts Mockly adapters
			// as valid replacements for shared adapters
		})
	})

	describe('Error Handling', () => {
		it('should create container even with missing dependencies', () => {
			// Test that the container is permissive at creation time
			// This is actually good behavior - allows for flexible injection
			const container = createCoreContainer({
				fileSystem: undefined as any,
				window: mockly.window,
				terminalProvider: mockly.terminal,
				process: mockly.workspace,
				path: mockly.node.path,
			})

			// The container should be created successfully
			expect(container).toBeDefined()
			expect(container.cradle).toBeDefined()
			
			// Service resolution should also work (awilix is permissive)
			const service = container.resolve('projectButlerService')
			expect(service).toBeDefined()
		})

		it('should fail gracefully at runtime when dependencies are invalid', async () => {
			// Test that the service handles invalid dependencies gracefully at runtime
			const invalidFileSystem = {
				// Missing required methods like 'stat', 'access', etc.
			}
			const mockWindow = {
				activeTextEditorUri: '/test/file.txt',
				showErrorMessage: vi.fn(),
				showTimedInformationMessage: vi.fn(),
			}

			const container = createCoreContainer({
				fileSystem: invalidFileSystem as any,
				window: mockWindow,
				terminalProvider: mockly.terminal,
				process: mockly.workspace,
				path: mockly.node.path,
			})

			const service = container.resolve('projectButlerService') as IProjectButlerService
			
			// The service should handle the invalid fileSystem gracefully
			// It will catch the error and show it via window.showErrorMessage
			await service.updateTerminalPath('/test/path')
			
			// Verify that the error was handled (no unhandled exception thrown)
			expect(service).toBeDefined() // Service continues to exist after error
		})
	})
}) 