import { vi, beforeEach } from 'vitest'
import { mockly, mocklyService } from '@fux/mockly'
import { ProjectButlerService } from '../src/services/ProjectButler.service.js'
import type { IWindow } from '../src/_interfaces/IWindow.js'
import type { ITerminalProvider, ITerminal } from '../src/_interfaces/ITerminal.js'
import type { IPath } from '../src/_interfaces/IPath.js'

// Create wrapper functions that are Vitest mocks for testing
const mockShowErrorMessage = vi.fn().mockImplementation((_message: string) => {
	// Mock implementation - suppress output
})

const mockShowTimedInformationMessage = vi.fn().mockImplementation((_message: string) => {
	// Mock implementation - suppress output
})

// Create wrapper functions for file system methods
const mockFsAccess = vi.fn().mockResolvedValue(undefined)
const mockFsCopyFile = vi.fn().mockResolvedValue(undefined)
const mockFsStat = vi.fn().mockResolvedValue({
	type: 1, // File
	size: 1024,
	ctime: Date.now(),
	mtime: Date.now(),
})
const mockFsReadFile = vi.fn().mockResolvedValue('file content')
const mockFsWriteFile = vi.fn().mockResolvedValue(undefined)

// Create wrapper functions for terminal methods
const mockTerminalSendText = vi.fn().mockImplementation((_text: string) => {
	// Mock implementation - do nothing but don't throw
})

const mockTerminalShow = vi.fn().mockImplementation(() => {
	// Mock implementation - do nothing but don't throw
})

// Reset Mockly state between tests
beforeEach(() => {
	mocklyService.reset()
	
	// Clear all mock calls to prevent persistence between tests
	mockShowErrorMessage.mockClear()
	mockShowTimedInformationMessage.mockClear()
	mockFsAccess.mockClear()
	mockFsCopyFile.mockClear()
	mockFsStat.mockClear()
	mockFsReadFile.mockClear()
	mockFsWriteFile.mockClear()
	mockTerminalSendText.mockClear()
	mockTerminalShow.mockClear()
})

// Export Mockly for use in tests
export { mockly, mocklyService }

/**
 * Creates a test instance of ProjectButlerService with Mockly dependencies
 * that implement the same interfaces as shared adapters
 */
export function createTestProjectButlerService(): ProjectButlerService {
	// Use wrapper functions that are Vitest mocks for testing
	const mockFileSystem = {
		access: mockFsAccess,
		copyFile: mockFsCopyFile,
		stat: mockFsStat,
		readFile: mockFsReadFile,
		writeFile: mockFsWriteFile,
	}

	const mockWindow: IWindow = {
		activeTextEditorUri: mockly.window.activeTextEditorUri,
		showErrorMessage: mockShowErrorMessage,
		showTimedInformationMessage: mockShowTimedInformationMessage,
	}

	// Create a terminal provider that uses mock functions
	const mockTerminalProvider: ITerminalProvider = {
		activeTerminal: undefined, // Start with no active terminal
		createTerminal: vi.fn().mockImplementation((_name: string): ITerminal => ({
			sendText: mockTerminalSendText,
			show: mockTerminalShow,
		})),
	}

	const mockProcess = {
		getWorkspaceRoot: mockly.workspace.getWorkspaceRoot,
	}

	const mockPath: IPath = {
		basename: mockly.node.path.basename,
		join: mockly.node.path.join,
		dirname: mockly.node.path.dirname,
		relative: (from: string, to: string) => {
			// Simple relative path implementation for testing
			if (to.startsWith(from)) {
				return to.substring(from.length).replace(/^[\/\\]/, '')
			}
			return to
		},
	}

	return new ProjectButlerService(
		mockFileSystem,
		mockWindow,
		mockTerminalProvider,
		mockProcess,
		mockPath,
	)
}
