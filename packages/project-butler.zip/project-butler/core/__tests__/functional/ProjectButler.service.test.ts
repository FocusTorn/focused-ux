import { describe, it, expect, beforeEach, vi } from 'vitest'
import { createTestProjectButlerService } from '../_setup.js'
import * as path from 'node:path'

describe('ProjectButlerService', () => {
	let service: ReturnType<typeof createTestProjectButlerService>

	beforeEach(() => {
		service = createTestProjectButlerService()
	})

	describe('updateTerminalPath', () => {
		it('should handle missing URI gracefully', async () => {
			const mockWindow = (service as any).window

			mockWindow.activeTextEditorUri = undefined

			await service.updateTerminalPath()

			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('No file or folder context to update terminal path.')
		})

		it('should handle directory paths correctly', async () => {
			const mockFs = (service as any).fileSystem
			const mockTerminalProvider = (service as any).terminalProvider
			const mockWindow = (service as any).window

			mockFs.stat = vi.fn().mockResolvedValue({
				type: 2, // Directory
				size: 1024,
				ctime: Date.now(),
				mtime: Date.now(),
			})

			const mockTerminal = {
				name: 'F-UX Terminal',
				sendText: vi.fn(),
				show: vi.fn(),
				hide: vi.fn(),
				dispose: vi.fn(),
				processId: Promise.resolve(1),
				creationOptions: {},
				exitStatus: undefined,
				state: 1,
				shellIntegration: undefined,
			}

			mockTerminalProvider.activeTerminal = undefined
			mockTerminalProvider.createTerminal = vi.fn().mockReturnValue(mockTerminal)

			await service.updateTerminalPath('/test/directory')

			expect(mockFs.stat).toHaveBeenCalledWith('/test/directory')
			expect(mockTerminalProvider.createTerminal).toHaveBeenCalledWith('F-UX Terminal')
			expect(mockTerminal.sendText).toHaveBeenCalledWith('cd "/test/directory"')
			expect(mockTerminal.show).toHaveBeenCalled()
			expect(mockWindow.showErrorMessage).not.toHaveBeenCalled()
		})

		it('should handle file paths correctly by using directory', async () => {
			const mockFs = (service as any).fileSystem
			const mockTerminalProvider = (service as any).terminalProvider
			const mockWindow = (service as any).window

			mockFs.stat = vi.fn().mockResolvedValue({
				type: 1, // File
				size: 512,
				ctime: Date.now(),
				mtime: Date.now(),
			})

			const mockTerminal = {
				name: 'F-UX Terminal',
				sendText: vi.fn(),
				show: vi.fn(),
				hide: vi.fn(),
				dispose: vi.fn(),
				processId: Promise.resolve(1),
				creationOptions: {},
				exitStatus: undefined,
				state: 1,
				shellIntegration: undefined,
			}

			mockTerminalProvider.activeTerminal = undefined
			mockTerminalProvider.createTerminal = vi.fn().mockReturnValue(mockTerminal)

			await service.updateTerminalPath('/test/file.txt')

			expect(mockFs.stat).toHaveBeenCalledWith('/test/file.txt')
			expect(mockTerminalProvider.createTerminal).toHaveBeenCalledWith('F-UX Terminal')
			expect(mockTerminal.sendText).toHaveBeenCalledWith('cd "/test"')
			expect(mockTerminal.show).toHaveBeenCalled()
			expect(mockWindow.showErrorMessage).not.toHaveBeenCalled()
		})

		it('should use existing active terminal if available', async () => {
			const mockFs = (service as any).fileSystem
			const mockTerminalProvider = (service as any).terminalProvider
			const mockWindow = (service as any).window

			mockFs.stat = vi.fn().mockResolvedValue({
				type: 2, // Directory
				size: 1024,
				ctime: Date.now(),
				mtime: Date.now(),
			})

			const mockTerminal = {
				name: 'Existing Terminal',
				sendText: vi.fn(),
				show: vi.fn(),
				hide: vi.fn(),
				dispose: vi.fn(),
				processId: Promise.resolve(1),
				creationOptions: {},
				exitStatus: undefined,
				state: 1,
				shellIntegration: undefined,
			}

			mockTerminalProvider.activeTerminal = mockTerminal
			mockTerminalProvider.createTerminal = vi.fn()

			await service.updateTerminalPath('/test/directory')

			expect(mockFs.stat).toHaveBeenCalledWith('/test/directory')
			expect(mockTerminalProvider.createTerminal).not.toHaveBeenCalled()
			expect(mockTerminal.sendText).toHaveBeenCalledWith('cd "/test/directory"')
			expect(mockTerminal.show).toHaveBeenCalled()
			expect(mockWindow.showErrorMessage).not.toHaveBeenCalled()
		})

		it('should handle file system errors gracefully', async () => {
			const mockFs = (service as any).fileSystem
			const mockWindow = (service as any).window

			mockFs.stat = vi.fn().mockRejectedValue(new Error('File not found'))

			await service.updateTerminalPath('/nonexistent/path')

			expect(mockFs.stat).toHaveBeenCalledWith('/nonexistent/path')
			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('Error updating terminal path: File not found')
		})
	})

	describe('createBackup', () => {
		it('should handle missing URI gracefully', async () => {
			const mockWindow = (service as any).window

			mockWindow.activeTextEditorUri = undefined

			await service.createBackup()

			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('No file selected or open to back up.')
		})

		it('should create backup with default naming when no backup exists', async () => {
			const mockFs = (service as any).fileSystem
			const mockWindow = (service as any).window

			// Mock file access to fail (backup doesn't exist)
			mockFs.access = vi.fn().mockRejectedValue(new Error('File not found'))
			mockFs.copyFile = vi.fn().mockResolvedValue(undefined)

			await service.createBackup('/test/file.txt')

			// Use forward slashes for cross-platform consistency with Mockly
			const expectedBackupPath = '/test/file.txt.bak'

			expect(mockFs.access).toHaveBeenCalledWith(expectedBackupPath)
			expect(mockFs.copyFile).toHaveBeenCalledWith('/test/file.txt', expectedBackupPath)
			expect(mockWindow.showTimedInformationMessage).toHaveBeenCalledWith('Backup created: file.txt.bak')
			expect(mockWindow.showErrorMessage).not.toHaveBeenCalled()
		})

		it('should create backup with incremented number when backup exists', async () => {
			const mockFs = (service as any).fileSystem
			const mockWindow = (service as any).window

			// Mock first backup exists, second doesn't
			mockFs.access = vi.fn()
				.mockResolvedValueOnce(undefined) // First backup exists
				.mockRejectedValueOnce(new Error('File not found')) // Second backup doesn't exist
			mockFs.copyFile = vi.fn().mockResolvedValue(undefined)

			await service.createBackup('/test/file.txt')

			// Use forward slashes for cross-platform consistency with Mockly
			const expectedBackupPath1 = '/test/file.txt.bak'
			const expectedBackupPath2 = '/test/file.txt.bak2'

			expect(mockFs.access).toHaveBeenCalledWith(expectedBackupPath1)
			expect(mockFs.access).toHaveBeenCalledWith(expectedBackupPath2)
			expect(mockFs.copyFile).toHaveBeenCalledWith('/test/file.txt', expectedBackupPath2)
			expect(mockWindow.showTimedInformationMessage).toHaveBeenCalledWith('Backup created: file.txt.bak2')
			expect(mockWindow.showErrorMessage).not.toHaveBeenCalled()
		})

		it('should handle multiple existing backups correctly', async () => {
			const mockFs = (service as any).fileSystem
			const mockWindow = (service as any).window

			// Mock first 3 backups exist, 4th doesn't
			mockFs.access = vi.fn()
				.mockResolvedValueOnce(undefined) // .bak exists
				.mockResolvedValueOnce(undefined) // .bak2 exists
				.mockResolvedValueOnce(undefined) // .bak3 exists
				.mockRejectedValueOnce(new Error('File not found')) // .bak4 doesn't exist
			mockFs.copyFile = vi.fn().mockResolvedValue(undefined)

			await service.createBackup('/test/file.txt')

			// Use forward slashes for cross-platform consistency with Mockly
			const expectedBackupPath1 = '/test/file.txt.bak'
			const expectedBackupPath2 = '/test/file.txt.bak2'
			const expectedBackupPath3 = '/test/file.txt.bak3'
			const expectedBackupPath4 = '/test/file.txt.bak4'

			expect(mockFs.access).toHaveBeenCalledWith(expectedBackupPath1)
			expect(mockFs.access).toHaveBeenCalledWith(expectedBackupPath2)
			expect(mockFs.access).toHaveBeenCalledWith(expectedBackupPath3)
			expect(mockFs.access).toHaveBeenCalledWith(expectedBackupPath4)
			expect(mockFs.copyFile).toHaveBeenCalledWith('/test/file.txt', expectedBackupPath4)
			expect(mockWindow.showTimedInformationMessage).toHaveBeenCalledWith('Backup created: file.txt.bak4')
		})

		it('should handle file system errors gracefully', async () => {
			const mockFs = (service as any).fileSystem
			const mockWindow = (service as any).window

			mockFs.access = vi.fn().mockRejectedValue(new Error('File not found'))
			mockFs.copyFile = vi.fn().mockRejectedValue(new Error('Permission denied'))

			await service.createBackup('/test/file.txt')

			const expectedBackupPath = '/test/file.txt.bak'

			expect(mockFs.copyFile).toHaveBeenCalledWith('/test/file.txt', expectedBackupPath)
			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('Error creating backup: Permission denied')
		})
	})

	describe('enterPoetryShell', () => {
		it('should handle missing URI gracefully', async () => {
			const mockWindow = (service as any).window

			mockWindow.activeTextEditorUri = undefined

			await service.enterPoetryShell()

			// Should not show error message for missing URI - poetry shell can run without context
			expect(mockWindow.showErrorMessage).not.toHaveBeenCalled()
		})

		it('should create poetry shell with basic command when no URI provided', async () => {
			const mockTerminalProvider = (service as any).terminalProvider
			const mockWindow = (service as any).window

			// Clear the active text editor to ensure no URI is used
			mockWindow.activeTextEditorUri = undefined

			const mockTerminal = {
				name: 'Poetry Shell',
				sendText: vi.fn(),
				show: vi.fn(),
				hide: vi.fn(),
				dispose: vi.fn(),
				processId: Promise.resolve(1),
				creationOptions: {},
				exitStatus: undefined,
				state: 1,
				shellIntegration: undefined,
			}

			mockTerminalProvider.createTerminal = vi.fn().mockReturnValue(mockTerminal)

			await service.enterPoetryShell()

			expect(mockTerminalProvider.createTerminal).toHaveBeenCalledWith('Poetry Shell')
			expect(mockTerminal.sendText).toHaveBeenCalledWith('poetry shell')
			expect(mockTerminal.show).toHaveBeenCalled()
			expect(mockWindow.showErrorMessage).not.toHaveBeenCalled()
		})

		it('should create poetry shell with directory context when URI provided', async () => {
			const mockFs = (service as any).fileSystem
			const mockTerminalProvider = (service as any).terminalProvider
			const mockWindow = (service as any).window

			mockFs.stat = vi.fn().mockResolvedValue({
				type: 2, // Directory
				size: 1024,
				ctime: Date.now(),
				mtime: Date.now(),
			})

			const mockTerminal = {
				name: 'Poetry Shell',
				sendText: vi.fn(),
				show: vi.fn(),
				hide: vi.fn(),
				dispose: vi.fn(),
				processId: Promise.resolve(1),
				creationOptions: {},
				exitStatus: undefined,
				state: 1,
				shellIntegration: undefined,
			}

			mockTerminalProvider.createTerminal = vi.fn().mockReturnValue(mockTerminal)

			await service.enterPoetryShell('/test/directory')

			expect(mockFs.stat).toHaveBeenCalledWith('/test/directory')
			expect(mockTerminalProvider.createTerminal).toHaveBeenCalledWith('Poetry Shell')
			expect(mockTerminal.sendText).toHaveBeenCalledWith('cd "/test/directory" && poetry shell')
			expect(mockTerminal.show).toHaveBeenCalled()
			expect(mockWindow.showErrorMessage).not.toHaveBeenCalled()
		})

		it('should create poetry shell with file directory context when file URI provided', async () => {
			const mockFs = (service as any).fileSystem
			const mockTerminalProvider = (service as any).terminalProvider
			const mockWindow = (service as any).window

			mockFs.stat = vi.fn().mockResolvedValue({
				type: 1, // File
				size: 512,
				ctime: Date.now(),
				mtime: Date.now(),
			})

			const mockTerminal = {
				name: 'Poetry Shell',
				sendText: vi.fn(),
				show: vi.fn(),
				hide: vi.fn(),
				dispose: vi.fn(),
				processId: Promise.resolve(1),
				creationOptions: {},
				exitStatus: undefined,
				state: 1,
				shellIntegration: undefined,
			}

			mockTerminalProvider.createTerminal = vi.fn().mockReturnValue(mockTerminal)

			await service.enterPoetryShell('/test/file.txt')

			expect(mockFs.stat).toHaveBeenCalledWith('/test/file.txt')
			expect(mockTerminalProvider.createTerminal).toHaveBeenCalledWith('Poetry Shell')
			expect(mockTerminal.sendText).toHaveBeenCalledWith('cd "/test" && poetry shell')
			expect(mockTerminal.show).toHaveBeenCalled()
			expect(mockWindow.showErrorMessage).not.toHaveBeenCalled()
		})

		it('should handle file system errors gracefully', async () => {
			const mockFs = (service as any).fileSystem
			const mockWindow = (service as any).window

			mockFs.stat = vi.fn().mockRejectedValue(new Error('File not found'))

			await service.enterPoetryShell('/nonexistent/path')

			expect(mockFs.stat).toHaveBeenCalledWith('/nonexistent/path')
			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('Failed to enter Poetry shell: File not found')
		})
	})

	describe('formatPackageJson', () => {
		it('should handle missing URI gracefully', async () => {
			const mockWindow = (service as any).window

			mockWindow.activeTextEditorUri = undefined

			await service.formatPackageJson()

			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('No package.json file selected or active.')
		})

		it('should validate package.json file extension', async () => {
			const mockWindow = (service as any).window

			await service.formatPackageJson('/test/file.txt')

			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('This command can only be run on a package.json file.')
		})

		it('should handle missing workspace root', async () => {
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue(undefined)

			await service.formatPackageJson('/test/package.json')

			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('Could not find workspace root. Cannot format package.json.')
		})

		it('should handle missing .FocusedUX config file', async () => {
			const mockFs = (service as any).fileSystem
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue('/workspace/root')
			mockFs.readFile = vi.fn().mockRejectedValue(new Error('Config file not found'))

			await service.formatPackageJson('/test/package.json')

			const expectedConfigPath = '/workspace/root/.FocusedUX'

			expect(mockFs.readFile).toHaveBeenCalledWith(expectedConfigPath)
			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('Could not read \'.FocusedUX\' file: Config file not found')
		})

		it('should handle invalid YAML in .FocusedUX config', async () => {
			const mockFs = (service as any).fileSystem
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue('/workspace/root')
			mockFs.readFile = vi.fn().mockResolvedValue('invalid: yaml: content')

			await service.formatPackageJson('/test/package.json')

			const expectedConfigPath = '/workspace/root/.FocusedUX'

			expect(mockFs.readFile).toHaveBeenCalledWith(expectedConfigPath)
			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith(expect.stringContaining('Failed to parse YAML from \'.FocusedUX\': '))
		})

		it('should handle missing packageJson-order configuration', async () => {
			const mockFs = (service as any).fileSystem
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue('/workspace/root')
			mockFs.readFile = vi.fn().mockResolvedValue('other: config')

			await service.formatPackageJson('/test/package.json')

			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('Configuration Error: \'TerminalButler.packageJson-order\' not found or invalid in \'.FocusedUX\'.')
		})

		it('should handle invalid packageJson-order configuration (not array)', async () => {
			const mockFs = (service as any).fileSystem
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue('/workspace/root')
			mockFs.readFile = vi.fn().mockResolvedValue(`
TerminalButler:
  packageJson-order: "not an array"
`)

			await service.formatPackageJson('/test/package.json')

			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('Configuration Error: \'TerminalButler.packageJson-order\' not found or invalid in \'.FocusedUX\'.')
		})

		it('should handle package.json read errors', async () => {
			const mockFs = (service as any).fileSystem
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue('/workspace/root')
			mockFs.readFile = vi.fn()
				.mockResolvedValueOnce(`
TerminalButler:
  packageJson-order:
    - name
    - version
    - description
`) // Config file
				.mockRejectedValueOnce(new Error('Package.json not found')) // Package.json file

			await service.formatPackageJson('/test/package.json')

			expect(mockFs.readFile).toHaveBeenCalledWith('/test/package.json')
			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('Failed to read package.json: Package.json not found')
		})

		it('should handle invalid JSON in package.json', async () => {
			const mockFs = (service as any).fileSystem
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue('/workspace/root')
			mockFs.readFile = vi.fn()
				.mockResolvedValueOnce(`
TerminalButler:
  packageJson-order:
    - name
    - version
    - description
`) // Config file
				.mockResolvedValueOnce('invalid json content') // Package.json file

			await service.formatPackageJson('/test/package.json')

			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('Failed to format package.json: Unexpected token \'i\', "invalid json content" is not valid JSON')
		})

		it('should handle unknown keys in package.json', async () => {
			const mockFs = (service as any).fileSystem
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue('/workspace/root')
			mockFs.readFile = vi.fn()
				.mockResolvedValueOnce(`
TerminalButler:
  packageJson-order:
    - name
    - version
    - description
`) // Config file
				.mockResolvedValueOnce(`
{
  "name": "test-package",
  "version": "1.0.0",
  "description": "Test package",
  "unknownKey": "should fail"
}
`) // Package.json file

			await service.formatPackageJson('/test/package.json')

			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('Validation Failed: Found top-level key \'unknownKey\' which is not in the allowed ordering list defined in .FocusedUX.')
		})

		it('should preserve comment-like keys', async () => {
			const mockFs = (service as any).fileSystem
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue('/workspace/root')
			mockFs.readFile = vi.fn()
				.mockResolvedValueOnce(`
TerminalButler:
  packageJson-order:
    - name
    - version
    - description
    - //comment
    - //another
`) // Config file - include comment keys in allowed list
				.mockResolvedValueOnce(`
{
  "name": "test-package",
  "version": "1.0.0",
  "description": "Test package",
  "//comment": "This is a comment",
  "//another": "Another comment"
}
`) // Package.json file

			mockFs.writeFile = vi.fn().mockResolvedValue(undefined)

			await service.formatPackageJson('/test/package.json')

			expect(mockFs.writeFile).toHaveBeenCalledWith('/test/package.json', expect.any(Uint8Array))
			
			// Verify the written content includes comments
			const writeCall = mockFs.writeFile.mock.calls[0]
			const writtenContent = new TextDecoder().decode(writeCall[1])

			expect(writtenContent).toContain('"//comment"')
			expect(writtenContent).toContain('"//another"')
			expect(mockWindow.showTimedInformationMessage).toHaveBeenCalledWith('Successfully formatted package.json')
		})

		it('should successfully format package.json with proper ordering', async () => {
			const mockFs = (service as any).fileSystem
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue('/workspace/root')
			mockFs.readFile = vi.fn()
				.mockResolvedValueOnce(`
TerminalButler:
  packageJson-order:
    - name
    - version
    - description
    - main
    - scripts
`) // Config file
				.mockResolvedValueOnce(`
{
  "scripts": {
    "test": "echo test"
  },
  "name": "test-package",
  "version": "1.0.0",
  "description": "Test package",
  "main": "index.js"
}
`) // Package.json file

			mockFs.writeFile = vi.fn().mockResolvedValue(undefined)

			await service.formatPackageJson('/test/package.json')

			expect(mockFs.writeFile).toHaveBeenCalledWith('/test/package.json', expect.any(Uint8Array))
			
			// Verify the written content is properly ordered
			const writeCall = mockFs.writeFile.mock.calls[0]
			const writtenContent = new TextDecoder().decode(writeCall[1])
			const parsedContent = JSON.parse(writtenContent)
			const keys = Object.keys(parsedContent)
			
			expect(keys[0]).toBe('name')
			expect(keys[1]).toBe('version')
			expect(keys[2]).toBe('description')
			expect(keys[3]).toBe('main')
			expect(keys[4]).toBe('scripts')
			
			expect(mockWindow.showTimedInformationMessage).toHaveBeenCalledWith('Successfully formatted package.json')
		})

		it('should ensure name is always first even if not in config', async () => {
			const mockFs = (service as any).fileSystem
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue('/workspace/root')
			mockFs.readFile = vi.fn()
				.mockResolvedValueOnce(`
TerminalButler:
  packageJson-order:
    - version
    - description
    - main
`) // Config file (name not included)
				.mockResolvedValueOnce(`
{
  "version": "1.0.0",
  "name": "test-package",
  "description": "Test package",
  "main": "index.js"
}
`) // Package.json file

			mockFs.writeFile = vi.fn().mockResolvedValue(undefined)

			await service.formatPackageJson('/test/package.json')

			expect(mockFs.writeFile).toHaveBeenCalledWith('/test/package.json', expect.any(Uint8Array))
			
			// Verify name is first even though it wasn't in the config
			const writeCall = mockFs.writeFile.mock.calls[0]
			const writtenContent = new TextDecoder().decode(writeCall[1])
			const parsedContent = JSON.parse(writtenContent)
			const keys = Object.keys(parsedContent)
			
			expect(keys[0]).toBe('name')
			expect(keys[1]).toBe('version')
			expect(keys[2]).toBe('description')
			expect(keys[3]).toBe('main')
			
			expect(mockWindow.showTimedInformationMessage).toHaveBeenCalledWith('Successfully formatted package.json')
		})

		it('should handle package.json write errors', async () => {
			const mockFs = (service as any).fileSystem
			const mockProcess = (service as any).process
			const mockWindow = (service as any).window

			mockProcess.getWorkspaceRoot = vi.fn().mockReturnValue('/workspace/root')
			mockFs.readFile = vi.fn()
				.mockResolvedValueOnce(`
TerminalButler:
  packageJson-order:
    - name
    - version
    - description
`) // Config file
				.mockResolvedValueOnce(`
{
  "name": "test-package",
  "version": "1.0.0",
  "description": "Test package"
}
`) // Package.json file

			mockFs.writeFile = vi.fn().mockRejectedValue(new Error('Write permission denied'))

			await service.formatPackageJson('/test/package.json')

			expect(mockFs.writeFile).toHaveBeenCalledWith('/test/package.json', expect.any(Uint8Array))
			expect(mockWindow.showErrorMessage).toHaveBeenCalledWith('Failed to write updated package.json: Write permission denied')
		})
	})
})
