// Export the extension and injection modules
export { activate, deactivate } from './extension.js'
export { createDIContainer } from './injection.js'
