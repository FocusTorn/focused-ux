// ESLint & Imports -->>

//--------------------------------------------------------------------------------------------------------------<<

export interface IFileUtilsService {
	formatFileSize: (bytes: number) => string
}
